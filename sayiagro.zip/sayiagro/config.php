<?php
declare(strict_types=1);

return [
    'dsn' => getenv('SAYIAGRO_DB_DSN') ?: 'mysql:host=127.0.0.1;dbname=sayiagro;charset=utf8mb4',
    'db_user' => getenv('SAYIAGRO_DB_USER') ?: 'root',
    'db_password' => getenv('SAYIAGRO_DB_PASSWORD') ?: '',
    'app_url' => rtrim(getenv('SAYIAGRO_APP_URL') ?: 'http://localhost/SAYIAGRO', '/'),
    'mail_from' => getenv('SAYIAGRO_MAIL_FROM') ?: 'no-reply@sayiagro.org',
    // Namba ya WhatsApp ya biashara (tarakimu tu, na code ya nchi, bila +). Badilisha hapa au kwa SAYIAGRO_WHATSAPP.
    'whatsapp_number' => preg_replace('/\D+/', '', getenv('SAYIAGRO_WHATSAPP') ?: '255785125046'),
    'sms_username' => getenv('SAYIAGRO_SMS_USERNAME') ?: '',
    'sms_api_key' => getenv('SAYIAGRO_SMS_API_KEY') ?: '',
    'sms_sender' => getenv('SAYIAGRO_SMS_SENDER') ?: '',
    'sms_api_url' => getenv('SAYIAGRO_SMS_API_URL') ?: 'https://api.africastalking.com/version1/messaging',
];
