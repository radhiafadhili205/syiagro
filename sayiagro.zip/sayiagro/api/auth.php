<?php
declare(strict_types=1);
require __DIR__ . '/common.php';

$pdo = database();
$action = $_GET['action'] ?? '';
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

if ($action === 'csrf' && $method === 'GET') {
    json_response(['csrf' => csrf_token()]);
}

if ($action === 'me' && $method === 'GET') {
    json_response(['user' => current_user(), 'csrf' => csrf_token()]);
}

if ($action === 'profile-details' && $method === 'GET') {
    $user = require_user();
    $stmt = $pdo->prepare('SELECT phone, location FROM users WHERE id = ?');
    $stmt->execute([$user['id']]);
    $details = $stmt->fetch() ?: [];
    json_response(['phone' => $details['phone'] ?? '', 'location' => $details['location'] ?? '']);
}

if ($action === 'logout' && $method === 'POST') {
    require_csrf();
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
    }
    session_destroy();
    json_response(['ok' => true]);
}

if ($action === 'register' && $method === 'POST') {
    require_csrf();
    $input = request_json();
    $first = trim((string) ($input['firstName'] ?? ''));
    $last = trim((string) ($input['lastName'] ?? ''));
    $email = strtolower(trim((string) ($input['email'] ?? '')));
    $phone = trim((string) ($input['phone'] ?? ''));
    $location = mb_substr(trim((string) ($input['location'] ?? '')), 0, 160);
    $password = (string) ($input['password'] ?? '');
    if (mb_strlen($first) < 2 || mb_strlen($last) < 2 || !filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($password) < 8) {
        json_response(['error' => 'Enter valid names and email. Password must be at least 8 characters.'], 422);
    }
    try {
        $stmt = $pdo->prepare('INSERT INTO users (first_name, last_name, email, phone, location, password_hash, role) VALUES (?, ?, ?, ?, ?, ?, \'customer\')');
        $stmt->execute([$first, $last, $email, $phone, $location, password_hash($password, PASSWORD_DEFAULT)]);
        $newId = (int) $pdo->lastInsertId();
        notify_user($newId, 'welcome', 'Welcome to SAYI AGRO', 'Your account is ready. Updates about your orders and account appear here and are also sent by email and SMS.', '', true);
        notify_staff('user', 'New customer registered', $first . ' ' . $last . ' (' . $email . ')', 'users', ['admin']);
        $user = ['id' => (int) $pdo->lastInsertId(), 'name' => $first . ' ' . $last, 'email' => $email, 'role' => 'customer'];
        session_regenerate_id(true);
        $_SESSION['user'] = $user;
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
        json_response(['user' => $user, 'csrf' => csrf_token()], 201);
    } catch (PDOException $exception) {
        if ($exception->getCode() === '23000') {
            json_response(['error' => 'An account with this email already exists.'], 409);
        }
        throw $exception;
    }
}

if ($action === 'login' && $method === 'POST') {
    require_csrf();
    $input = request_json();
    $email = strtolower(trim((string) ($input['email'] ?? '')));
    $password = (string) ($input['password'] ?? '');
    $stmt = $pdo->prepare('SELECT id, first_name, last_name, email, role, password_hash, is_active FROM users WHERE email = ? LIMIT 1');
    $stmt->execute([$email]);
    $account = $stmt->fetch();
    if (!$account || !(int) $account['is_active'] || !password_verify($password, $account['password_hash'])) {
        json_response(['error' => 'Email or password is incorrect.'], 401);
    }
    session_regenerate_id(true);
    $_SESSION['user'] = ['id' => (int) $account['id'], 'name' => $account['first_name'] . ' ' . $account['last_name'], 'email' => $account['email'], 'role' => $account['role']];
    $_SESSION['csrf'] = bin2hex(random_bytes(32));
    json_response(['user' => $_SESSION['user'], 'csrf' => csrf_token()]);
}

if ($action === 'forgot' && $method === 'POST') {
    require_csrf();
    $input = request_json();
    $email = strtolower(trim((string) ($input['email'] ?? '')));
    $debugOtp = null;
    if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $stmt = $pdo->prepare('SELECT id, phone FROM users WHERE email = ? AND is_active = 1 LIMIT 1');
        $stmt->execute([$email]);
        $account = $stmt->fetch();
        if ($account) {
            $recent = $pdo->prepare('SELECT id FROM password_reset_requests WHERE user_id=? AND last_sms_at > DATE_SUB(NOW(), INTERVAL 60 SECOND) LIMIT 1');
            $recent->execute([$account['id']]);
            if (!$recent->fetchColumn()) {
                $otp = str_pad((string) random_int(0, 999999), 6, '0', STR_PAD_LEFT);
                $pdo->prepare("UPDATE password_reset_requests SET status='rejected' WHERE user_id=? AND status IN ('pending_admin', 'otp_sent')")->execute([$account['id']]);
                $pdo->prepare("INSERT INTO password_reset_requests (user_id, status, otp_hash, otp_expires_at, otp_attempts, last_sms_at) VALUES (?, 'otp_sent', ?, DATE_ADD(NOW(), INTERVAL 10 MINUTE), 0, NOW())")->execute([$account['id'], password_hash($otp, PASSWORD_DEFAULT)]);
                $text = 'Your SAYI AGRO security code is ' . $otp . '. It expires in 10 minutes. If you did not request it, ignore this message.';
                send_email($email, 'SAYI AGRO security code', $text);
                if (!empty($account['phone'])) send_sms((string) $account['phone'], $text);
                global $config;
                if (!empty($config['debug_show_otp'])) $debugOtp = $otp;
            }
        }
    }
    $response = ['ok' => true, 'message' => 'If this account exists, a six-digit security code has been sent to its registered email and phone.'];
    if ($debugOtp !== null) $response['debug_otp'] = $debugOtp;
    json_response($response);
}

if ($action === 'request-admin-help' && $method === 'POST') {
    require_csrf();
    $input = request_json();
    $email = strtolower(trim((string) ($input['email'] ?? '')));
    if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $stmt = $pdo->prepare('SELECT id, first_name, last_name FROM users WHERE email = ? AND is_active = 1 LIMIT 1');
        $stmt->execute([$email]);
        $account = $stmt->fetch();
        if ($account) {
            $open = $pdo->prepare("SELECT id FROM password_reset_requests WHERE user_id = ? AND status = 'pending_admin' LIMIT 1");
            $open->execute([$account['id']]);
            if (!$open->fetchColumn()) {
                $pdo->prepare("INSERT INTO password_reset_requests (user_id, status) VALUES (?, 'pending_admin')")->execute([$account['id']]);
                notify_staff('reset', 'Password reset request', $account['first_name'] . ' ' . $account['last_name'] . ' (' . $email . ') needs help to reset the password.', 'password-resets', ['admin']);
            }
        }
    }
    json_response(['ok' => true, 'message' => 'If this account exists, the administrator has been notified. They will send or give you a code. Then choose "I already have a code" below.']);
}

if ($action === 'verify-otp' && $method === 'POST') {
    require_csrf();
    $input = request_json();
    $email = strtolower(trim((string) ($input['email'] ?? '')));
    $otp = trim((string) ($input['otp'] ?? ''));
    if (!filter_var($email, FILTER_VALIDATE_EMAIL) || !preg_match('/^\d{6}$/', $otp)) {
        json_response(['error' => 'Enter the account email and the six-digit code.'], 422);
    }
    $pdo->beginTransaction();
    $stmt = $pdo->prepare("SELECT r.id, r.user_id, r.otp_hash, r.otp_attempts, (r.otp_expires_at > NOW()) AS still_valid FROM password_reset_requests r JOIN users u ON u.id=r.user_id WHERE u.email=? AND u.is_active=1 AND r.status='otp_sent' ORDER BY r.id DESC LIMIT 1 FOR UPDATE");
    $stmt->execute([$email]);
    $request = $stmt->fetch();
    if (!$request || empty($request['still_valid']) || (int) $request['otp_attempts'] >= 5) {
        $pdo->rollBack();
        json_response(['error' => 'The code is invalid or expired. Request a new code.'], 410);
    }
    if (!password_verify($otp, $request['otp_hash'])) {
        $attempts = (int) $request['otp_attempts'] + 1;
        $pdo->prepare('UPDATE password_reset_requests SET otp_attempts=? WHERE id=?')->execute([$attempts, $request['id']]);
        $pdo->commit();
        json_response(['error' => $attempts >= 5 ? 'Too many incorrect codes. Request a new code.' : 'The code is incorrect.'], 422);
    }

    $token = bin2hex(random_bytes(32));
    $pdo->prepare('DELETE FROM password_reset_tokens WHERE user_id=? OR expires_at < NOW()')->execute([$request['user_id']]);
    $pdo->prepare('INSERT INTO password_reset_tokens (user_id, token_hash, expires_at) VALUES (?, ?, DATE_ADD(NOW(), INTERVAL 60 MINUTE))')->execute([$request['user_id'], hash('sha256', $token)]);
    $pdo->prepare("UPDATE password_reset_requests SET status='verified' WHERE id=?")->execute([$request['id']]);
    $pdo->commit();
    json_response(['ok' => true, 'token' => $token, 'message' => 'Code verified. Choose a new password.']);
}

if ($action === 'reset' && $method === 'POST') {
    require_csrf();
    $input = request_json();
    $token = (string) ($input['token'] ?? '');
    $password = (string) ($input['password'] ?? '');
    if (strlen($token) !== 64 || strlen($password) < 8) {
        json_response(['error' => 'The reset link or password is invalid.'], 422);
    }
    $pdo->beginTransaction();
    $stmt = $pdo->prepare('SELECT id, user_id FROM password_reset_tokens WHERE token_hash = ? AND used_at IS NULL AND expires_at > NOW() FOR UPDATE');
    $stmt->execute([hash('sha256', $token)]);
    $reset = $stmt->fetch();
    if (!$reset) {
        $pdo->rollBack();
        json_response(['error' => 'This reset link is invalid or has expired.'], 410);
    }
    $pdo->prepare('UPDATE users SET password_hash = ? WHERE id = ?')->execute([password_hash($password, PASSWORD_DEFAULT), $reset['user_id']]);
    $pdo->prepare('UPDATE password_reset_tokens SET used_at = NOW() WHERE user_id = ?')->execute([$reset['user_id']]);
    $pdo->prepare("UPDATE password_reset_requests SET status='completed' WHERE user_id=? AND status='verified'")->execute([$reset['user_id']]);
    $pdo->commit();
    notify_user((int) $reset['user_id'], 'security', 'Password changed', 'Your password was changed. If this was not you, contact SAYI AGRO immediately.', '', true);
    json_response(['ok' => true, 'message' => 'Password updated. You can now sign in.']);
}

if ($action === 'change-password' && $method === 'POST') {
    $user = require_user();
    require_csrf();
    $input = request_json();
    $current = (string) ($input['currentPassword'] ?? '');
    $new = (string) ($input['newPassword'] ?? '');
    $min = in_array($user['role'], ['admin', 'hr'], true) ? 12 : 8;
    if (strlen($new) < $min) json_response(['error' => 'The new password must be at least ' . $min . ' characters.'], 422);
    $stmt = $pdo->prepare('SELECT password_hash FROM users WHERE id = ?');
    $stmt->execute([$user['id']]);
    if (!password_verify($current, (string) $stmt->fetchColumn())) json_response(['error' => 'Current password is incorrect.'], 403);
    $pdo->prepare('UPDATE users SET password_hash = ? WHERE id = ?')->execute([password_hash($new, PASSWORD_DEFAULT), $user['id']]);
    session_regenerate_id(true);
    notify_user((int) $user['id'], 'security', 'Password changed', 'Your password was changed. If this was not you, contact SAYI AGRO immediately.', '', true);
    json_response(['ok' => true, 'message' => 'Password updated.']);
}

if ($action === 'change-email' && $method === 'POST') {
    $user = require_user();
    require_csrf();
    $input = request_json();
    $email = strtolower(trim((string) ($input['newEmail'] ?? '')));
    $current = (string) ($input['currentPassword'] ?? '');
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) json_response(['error' => 'Enter a valid email address.'], 422);
    $stmt = $pdo->prepare('SELECT password_hash FROM users WHERE id = ?');
    $stmt->execute([$user['id']]);
    if (!password_verify($current, (string) $stmt->fetchColumn())) json_response(['error' => 'Current password is incorrect.'], 403);
    try {
        $pdo->prepare('UPDATE users SET email = ? WHERE id = ?')->execute([$email, $user['id']]);
    } catch (PDOException $exception) {
        if ($exception->getCode() === '23000') json_response(['error' => 'That email is already used by another account.'], 409);
        throw $exception;
    }
    $_SESSION['user']['email'] = $email;
    notify_user((int) $user['id'], 'security', 'Email changed', 'Your sign-in email is now ' . $email . '.', '', true);
    json_response(['ok' => true, 'email' => $email, 'message' => 'Email updated. Use it the next time you sign in.']);
}

if ($action === 'profile' && $method === 'POST') {
    $user = require_user();
    require_csrf();
    $input = request_json();
    $first = trim((string) ($input['firstName'] ?? ''));
    $last = trim((string) ($input['lastName'] ?? ''));
    $phone = trim((string) ($input['phone'] ?? ''));
    $location = array_key_exists('location', $input) ? mb_substr(trim((string) $input['location']), 0, 160) : null;
    if (mb_strlen($first) < 2 || mb_strlen($last) < 2) {
        json_response(['error' => 'First and last names must have at least 2 characters.'], 422);
    }
    $pdo->prepare('UPDATE users SET first_name = ?, last_name = ?, phone = ?, location = COALESCE(?, location) WHERE id = ?')->execute([$first, $last, $phone, $location, $user['id']]);
    $_SESSION['user']['name'] = $first . ' ' . $last;
    json_response(['user' => $_SESSION['user']]);
}

json_response(['error' => 'Unknown action.'], 404);
