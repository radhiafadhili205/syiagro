<?php
declare(strict_types=1);

$config = require __DIR__ . '/../config.php';

$isHttps = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';
session_set_cookie_params([
    'httponly' => true,
    'secure' => $isHttps,
    'samesite' => 'Lax',
    'path' => '/',
]);
session_start();

function json_response(array $payload, int $status = 200): never
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    echo json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
}

function database(): PDO
{
    global $config;
    static $pdo;
    if (!$pdo) {
        $pdo = new PDO($config['dsn'], $config['db_user'], $config['db_password'], [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]);
    }
    return $pdo;
}

function request_json(): array
{
    $data = json_decode((string) file_get_contents('php://input'), true);
    return is_array($data) ? $data : [];
}

function current_user(): ?array
{
    return isset($_SESSION['user']) && is_array($_SESSION['user']) ? $_SESSION['user'] : null;
}

function require_user(array $roles = []): array
{
    $user = current_user();
    if (!$user) {
        json_response(['error' => 'Sign in required.'], 401);
    }
    if ($roles && !in_array($user['role'], $roles, true)) {
        json_response(['error' => 'You do not have permission to perform this action.'], 403);
    }
    return $user;
}

function csrf_token(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function require_csrf(): void
{
    $provided = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
    if (!$provided || !hash_equals(csrf_token(), $provided)) {
        json_response(['error' => 'Invalid security token. Refresh and try again.'], 419);
    }
}

function audit(string $action, string $type, ?int $entityId = null, array $details = []): void
{
    $user = current_user();
    $statement = database()->prepare('INSERT INTO activity_log (actor_id, action, entity_type, entity_id, details) VALUES (?, ?, ?, ?, ?)');
    $statement->execute([$user['id'] ?? null, $action, $type, $entityId, json_encode($details)]);
}

function send_reset_email(string $email, string $url): bool
{
    global $config;
    $headers = "From: SAYI AGRO FOUNDATION <" . $config['mail_from'] . ">\r\n";
    $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";
    $body = "Use this one-time link to reset your password. It expires in 60 minutes:\n\n" . $url . "\n\nIf you did not request this, ignore this email.";
    return mail($email, 'Reset your SAYI AGRO password', $body, $headers);
}

function smtp_send(string $to, string $subject, string $body): bool
{
    global $config;
    $secure = strtolower((string) $config['smtp_secure']);
    $remote = ($secure === 'ssl' ? 'ssl://' : '') . $config['smtp_host'] . ':' . (int) $config['smtp_port'];
    $fp = @stream_socket_client($remote, $errno, $errstr, 15);
    if (!$fp) { error_log('SMTP connect failed: ' . $errstr); return false; }
    stream_set_timeout($fp, 15);
    $read = function () use ($fp): string {
        $out = '';
        while (($line = fgets($fp, 515)) !== false) { $out .= $line; if (strlen($line) < 4 || $line[3] === ' ') break; }
        return $out;
    };
    $cmd = function (string $command, array $ok) use ($fp, $read): bool {
        fwrite($fp, $command . "\r\n");
        return in_array((int) substr($read(), 0, 3), $ok, true);
    };
    $read();
    if (!$cmd('EHLO localhost', [250])) { fclose($fp); return false; }
    if ($secure === 'tls') {
        if (!$cmd('STARTTLS', [220]) || !stream_socket_enable_crypto($fp, true, STREAM_CRYPTO_METHOD_TLS_CLIENT) || !$cmd('EHLO localhost', [250])) { fclose($fp); return false; }
    }
    if ((string) $config['smtp_user'] !== '') {
        if (!$cmd('AUTH LOGIN', [334]) || !$cmd(base64_encode((string) $config['smtp_user']), [334]) || !$cmd(base64_encode((string) $config['smtp_password']), [235])) { error_log('SMTP login failed.'); fclose($fp); return false; }
    }
    $from = (string) ($config['smtp_user'] !== '' ? $config['smtp_user'] : $config['mail_from']);
    if (!$cmd('MAIL FROM:<' . $from . '>', [250]) || !$cmd('RCPT TO:<' . $to . '>', [250, 251]) || !$cmd('DATA', [354])) { fclose($fp); return false; }
    $message = 'From: SAYI AGRO FOUNDATION <' . $from . ">\r\n" . 'To: <' . $to . ">\r\n" . 'Subject: =?UTF-8?B?' . base64_encode($subject) . "?=\r\n" . "MIME-Version: 1.0\r\nContent-Type: text/plain; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n" . chunk_split(base64_encode($body));
    fwrite($fp, $message . "\r\n.\r\n");
    $sent = (int) substr($read(), 0, 3) === 250;
    $cmd('QUIT', [221]);
    fclose($fp);
    return $sent;
}

function send_email(string $to, string $subject, string $body): bool
{
    global $config;
    if (!filter_var($to, FILTER_VALIDATE_EMAIL)) return false;
    if ((string) ($config['smtp_host'] ?? '') !== '') return smtp_send($to, $subject, $body);
    $headers = 'From: SAYI AGRO FOUNDATION <' . $config['mail_from'] . ">\r\nContent-Type: text/plain; charset=UTF-8\r\n";
    return (bool) @mail($to, $subject, $body, $headers);
}

function notify_user(int $userId, string $type, string $title, string $body = '', string $link = '', bool $external = false): void
{
    try {
        $pdo = database();
        $pdo->prepare('INSERT INTO notifications (user_id, type, title, body, link) VALUES (?, ?, ?, ?, ?)')->execute([$userId, $type, mb_substr($title, 0, 160), mb_substr($body, 0, 500), mb_substr($link, 0, 160)]);
        if (!$external) return;
        $stmt = $pdo->prepare('SELECT email, phone FROM users WHERE id=? AND is_active=1');
        $stmt->execute([$userId]);
        $account = $stmt->fetch();
        if (!$account) return;
        $text = $title . ($body !== '' ? ': ' . $body : '');
        if (!empty($account['email'])) send_email((string) $account['email'], 'SAYI AGRO: ' . $title, $text . "\n\nSAYI AGRO FOUNDATION");
        if (!empty($account['phone'])) send_sms((string) $account['phone'], mb_substr('SAYI AGRO: ' . $text, 0, 300));
    } catch (Throwable $exception) {
        error_log('notify_user failed: ' . $exception->getMessage());
    }
}

function notify_staff(string $type, string $title, string $body = '', string $link = '', array $roles = ['admin', 'hr'], int $exceptUserId = 0): void
{
    try {
        $marks = implode(',', array_fill(0, count($roles), '?'));
        $stmt = database()->prepare("SELECT id FROM users WHERE is_active=1 AND role IN ($marks)");
        $stmt->execute($roles);
        foreach ($stmt->fetchAll(PDO::FETCH_COLUMN) as $id) {
            if ((int) $id !== $exceptUserId) notify_user((int) $id, $type, $title, $body, $link, false);
        }
    } catch (Throwable $exception) {
        error_log('notify_staff failed: ' . $exception->getMessage());
    }
}

function normalize_sms_phone(string $phone): ?string
{
    $digits = preg_replace('/\D+/', '', $phone);
    if ($digits === '') return null;
    if (strpos($digits, '00') === 0) $digits = substr($digits, 2);
    if (strpos($digits, '0') === 0) $digits = '255' . substr($digits, 1);
    elseif (strlen($digits) === 9) $digits = '255' . $digits;
    if (strlen($digits) < 10 || strlen($digits) > 15) return null;
    return '+' . $digits;
}

function send_sms(string $phone, string $message): bool
{
    global $config;
    if (!$config['sms_username'] || !$config['sms_api_key'] || !function_exists('curl_init')) {
        error_log('SMS is not configured or PHP cURL is unavailable.');
        return false;
    }
    $number = normalize_sms_phone($phone);
    if (!$number) return false;
    $payload = ['username' => $config['sms_username'], 'to' => $number, 'message' => $message];
    if ($config['sms_sender'] !== '') $payload['from'] = $config['sms_sender'];
    $smsUrl = (string) $config['sms_api_url'];
    $smsHost = parse_url($smsUrl, PHP_URL_HOST);
    if (parse_url($smsUrl, PHP_URL_SCHEME) !== 'https' || !in_array($smsHost, ['api.africastalking.com', 'api.sandbox.africastalking.com'], true)) {
        error_log('SMS API URL is not an approved HTTPS endpoint.');
        return false;
    }
    $curl = curl_init($smsUrl);
    curl_setopt_array($curl, [
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => http_build_query($payload),
        CURLOPT_HTTPHEADER => ['apiKey: ' . $config['sms_api_key'], 'Accept: application/json'],
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_TIMEOUT => 20,
    ]);
    $response = curl_exec($curl);
    $status = (int) curl_getinfo($curl, CURLINFO_HTTP_CODE);
    if ($response === false) error_log('SMS provider request failed: ' . curl_error($curl));
    curl_close($curl);
    if ($response === false || $status < 200 || $status >= 300) return false;
    $decoded = json_decode($response, true);
    $recipients = $decoded['SMSMessageData']['Recipients'] ?? [];
    return isset($recipients[0]) && (($recipients[0]['status'] ?? '') === 'Success' || (int) ($recipients[0]['statusCode'] ?? 0) === 101);
}
