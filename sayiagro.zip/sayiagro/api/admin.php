<?php
declare(strict_types=1);
require __DIR__ . '/common.php';

$actor = require_user(['admin', 'hr']);
$pdo = database();
$action = $_GET['action'] ?? '';
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

// HR anaruhusiwa kusimamia: bidhaa, maombi ya ununuzi, events, gallery, miradi (projects) na mawasiliano ya customers.
// Users, Password resets na Site text ni za admin pekee.
$hrActions = ['summary', 'products', 'events', 'gallery', 'requests', 'customers', 'projects', 'product-save', 'product-clone', 'product-status', 'product-delete', 'event-save', 'event-delete', 'gallery-upload', 'gallery-delete', 'request-status', 'project-save', 'project-delete'];
if ($actor['role'] === 'hr' && !in_array($action, $hrActions, true)) {
    json_response(['error' => 'Administrator access is required.'], 403);
}

function uploaded_image(string $field = 'image'): ?string
{
    if (empty($_FILES[$field]) || $_FILES[$field]['error'] === UPLOAD_ERR_NO_FILE) {
        return null;
    }
    $file = $_FILES[$field];
    if ($file['error'] !== UPLOAD_ERR_OK || $file['size'] > 5 * 1024 * 1024) {
        json_response(['error' => 'Image upload failed or exceeds 5 MB.'], 422);
    }
    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']);
    $extensions = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp', 'image/gif' => 'gif'];
    if (!isset($extensions[$mime]) || !getimagesize($file['tmp_name'])) {
        json_response(['error' => 'Upload a valid JPG, PNG, WEBP, or GIF image.'], 422);
    }
    $directory = dirname(__DIR__) . '/uploads';
    if (!is_dir($directory) && !mkdir($directory, 0755, true)) {
        json_response(['error' => 'Upload directory is unavailable.'], 500);
    }
    $filename = bin2hex(random_bytes(20)) . '.' . $extensions[$mime];
    if (!move_uploaded_file($file['tmp_name'], $directory . '/' . $filename)) {
        json_response(['error' => 'Could not save uploaded image.'], 500);
    }
    return 'uploads/' . $filename;
}

function remove_upload(?string $path): void
{
    if (!$path || !str_starts_with($path, 'uploads/')) {
        return;
    }
    $file = dirname(__DIR__) . '/' . $path;
    if (is_file($file)) {
        unlink($file);
    }
}

if ($method === 'GET') {
    if ($action === 'summary') {
        $data = [
            'products' => (int) $pdo->query('SELECT COUNT(*) FROM products')->fetchColumn(),
            'pendingProducts' => (int) $pdo->query("SELECT COUNT(*) FROM products WHERE status = 'pending'")->fetchColumn(),
            'outOfStock' => (int) $pdo->query("SELECT COUNT(*) FROM products WHERE status = 'out_of_stock' OR quantity = 0")->fetchColumn(),
            'events' => (int) $pdo->query("SELECT COUNT(*) FROM events WHERE status = 'published'")->fetchColumn(),
            'gallery' => (int) $pdo->query('SELECT COUNT(*) FROM gallery_images')->fetchColumn(),
            'requests' => (int) $pdo->query("SELECT COUNT(*) FROM purchase_requests WHERE status IN ('submitted', 'reviewing')")->fetchColumn(),
            'passwordResets' => (int) $pdo->query("SELECT COUNT(*) FROM password_reset_requests WHERE status='pending_admin'")->fetchColumn(),
            'customers' => (int) $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'customer'")->fetchColumn(),
            'hr' => (int) $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'hr'")->fetchColumn(),
        ];
        json_response(['summary' => $data]);
    }
    if ($action === 'products') {
        $rows = $pdo->query('SELECT p.*, u.email AS seller_email, CONCAT(u.first_name, \' \', u.last_name) AS seller_name FROM products p LEFT JOIN users u ON u.id = p.seller_id ORDER BY p.created_at DESC')->fetchAll();
        json_response(['products' => $rows]);
    }
    if ($action === 'events') {
        json_response(['events' => $pdo->query('SELECT e.*, CONCAT(u.first_name, \' \', u.last_name) AS author FROM events e LEFT JOIN users u ON u.id = e.created_by ORDER BY e.event_date DESC, e.id DESC')->fetchAll()]);
    }
    if ($action === 'gallery') {
        json_response(['images' => $pdo->query('SELECT g.*, CONCAT(u.first_name, \' \', u.last_name) AS author FROM gallery_images g LEFT JOIN users u ON u.id = g.uploaded_by ORDER BY g.created_at DESC')->fetchAll()]);
    }
    if ($action === 'content') {
        $rows = $pdo->query('SELECT content_key, content_value, updated_at FROM site_content ORDER BY content_key')->fetchAll();
        $content = [];
        foreach ($rows as $row) $content[$row['content_key']] = ['value' => $row['content_value'], 'updated_at' => $row['updated_at']];
        json_response(['content' => $content]);
    }
    if ($action === 'customers') {
        json_response(['customers' => $pdo->query("SELECT id, first_name, last_name, email, is_active FROM users WHERE role='customer' AND is_active=1 ORDER BY first_name, last_name")->fetchAll()]);
    }
    if ($action === 'projects') {
        json_response(['projects' => $pdo->query('SELECT id, title, description, image_path, status, sort_order, created_at FROM foundation_projects ORDER BY sort_order, id')->fetchAll()]);
    }
    if ($action === 'users') {
        json_response(['users' => $pdo->query('SELECT id, first_name, last_name, email, phone, role, is_active, created_at FROM users ORDER BY created_at DESC')->fetchAll()]);
    }
    if ($action === 'requests') {
        $rows = $pdo->query('SELECT r.*, u.email AS customer_email, CONCAT(u.first_name, \' \', u.last_name) AS customer_name FROM purchase_requests r JOIN users u ON u.id = r.customer_id ORDER BY r.created_at DESC')->fetchAll();
        foreach ($rows as &$row) {
            $stmt = $pdo->prepare('SELECT product_name, quantity, unit_price FROM purchase_request_items WHERE request_id = ?');
            $stmt->execute([$row['id']]);
            $row['items'] = $stmt->fetchAll();
        }
        json_response(['requests' => $rows]);
    }
    if ($action === 'reset-requests') {
        $rows = $pdo->query("SELECT r.id, r.status, r.requested_at, r.last_sms_at, u.first_name, u.last_name, u.email, u.phone FROM password_reset_requests r JOIN users u ON u.id=r.user_id WHERE r.status IN ('pending_admin', 'otp_sent') ORDER BY r.requested_at DESC")->fetchAll();
        foreach ($rows as &$row) {
            $number = normalize_sms_phone((string) $row['phone']);
            $row['phone_hint'] = $number ? 'ending ' . substr($number, -4) : 'No valid phone';
            unset($row['phone']);
        }
        unset($row);
        json_response(['requests' => $rows]);
    }
    json_response(['error' => 'Unknown action.'], 404);
}

require_csrf();
$contentType = $_SERVER['CONTENT_TYPE'] ?? '';
$input = strpos($contentType, 'application/json') !== false ? request_json() : $_POST;

if ($action === 'product-save') {
    $id = (int) ($input['id'] ?? 0);
    $name = trim((string) ($input['name'] ?? ''));
    $description = trim((string) ($input['description'] ?? ''));
    $category = trim((string) ($input['category'] ?? 'Other'));
    $unit = trim((string) ($input['unit'] ?? 'unit'));
    $contactPhone = mb_substr(trim((string) ($input['contact_phone'] ?? '')), 0, 40);
    $locationText = mb_substr(trim((string) ($input['location'] ?? '')), 0, 160);
    $price = filter_var($input['price'] ?? null, FILTER_VALIDATE_FLOAT);
    $quantity = filter_var($input['quantity'] ?? null, FILTER_VALIDATE_INT);
    if ($name === '' || $price === false || $price <= 0 || $quantity === false || $quantity < 0) {
        json_response(['error' => 'Enter a product name, positive price, and valid stock quantity.'], 422);
    }
    $image = uploaded_image();
    $requestedStatus = (string) ($input['status'] ?? ($id ? 'pending' : 'active'));
    if (!in_array($requestedStatus, ['pending', 'active', 'rejected'], true)) $requestedStatus = 'pending';
    $status = $quantity === 0 ? 'out_of_stock' : $requestedStatus;
    if ($id) {
        $stmt = $pdo->prepare('SELECT image_path FROM products WHERE id = ?');
        $stmt->execute([$id]);
        $existingImage = $stmt->fetchColumn();
        if ($existingImage === false) json_response(['error' => 'Product not found.'], 404);
        $imagePath = $image ?: $existingImage;
        $pdo->prepare('UPDATE products SET name=?, description=?, category=?, price=?, quantity=?, unit=?, image_path=?, contact_phone=?, location=?, status=? WHERE id=?')->execute([$name, $description, $category, $price, $quantity, $unit, $imagePath, $contactPhone, $locationText, $status, $id]);
        if ($image) remove_upload($existingImage);
        audit('product.updated', 'product', $id);
    } else {
        $pdo->prepare('INSERT INTO products (seller_id, name, description, category, price, quantity, unit, image_path, contact_phone, location, status) VALUES (NULL, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)')->execute([$name, $description, $category, $price, $quantity, $unit, $image, $contactPhone, $locationText, $status]);
        $id = (int) $pdo->lastInsertId();
        audit('product.created', 'product', $id);
    }
    json_response(['ok' => true, 'id' => $id]);
}

if ($action === 'product-clone') {
    $id = (int) ($input['id'] ?? 0);
    $stmt = $pdo->prepare("INSERT INTO products (seller_id, name, description, category, price, quantity, unit, image_path, status) SELECT seller_id, CONCAT(name, ' (Copy)'), description, category, price, 0, unit, image_path, 'out_of_stock' FROM products WHERE id = ?");
    $stmt->execute([$id]);
    if (!$stmt->rowCount()) json_response(['error' => 'Product not found.'], 404);
    $newId = (int) $pdo->lastInsertId();
    audit('product.cloned', 'product', $newId, ['source_id' => $id]);
    json_response(['ok' => true, 'id' => $newId], 201);
}

if ($action === 'product-status') {
    $id = (int) ($input['id'] ?? 0);
    $status = (string) ($input['status'] ?? '');
    if (!in_array($status, ['pending', 'active', 'out_of_stock', 'rejected'], true)) json_response(['error' => 'Invalid product status.'], 422);
    $stmt = $pdo->prepare("UPDATE products SET status = IF(? = 'out_of_stock' OR quantity = 0, 'out_of_stock', ?), quantity = IF(? = 'out_of_stock', 0, quantity) WHERE id = ?");
    $stmt->execute([$status, $status, $status, $id]);
    $info = $pdo->prepare('SELECT seller_id, name FROM products WHERE id=?');
    $info->execute([$id]);
    $changed = $info->fetch();
    if ($changed && $changed['seller_id'] && in_array($status, ['active', 'rejected'], true)) {
        notify_user((int) $changed['seller_id'], 'product', $status === 'active' ? 'Product approved' : 'Product not approved', '"' . $changed['name'] . '" ' . ($status === 'active' ? 'is now visible in the marketplace.' : 'was not approved. Contact HR for details.'), '', true);
    }
    audit('product.status_changed', 'product', $id, ['status' => $status]);
    json_response(['ok' => true]);
}

if ($action === 'product-delete') {
    $id = (int) ($input['id'] ?? 0);
    $stmt = $pdo->prepare('SELECT image_path FROM products WHERE id = ?');
    $stmt->execute([$id]);
    $path = $stmt->fetchColumn();
    $pdo->prepare('DELETE FROM products WHERE id = ?')->execute([$id]);
    remove_upload($path ?: null);
    audit('product.deleted', 'product', $id);
    json_response(['ok' => true]);
}

if ($action === 'event-save') {
    $id = (int) ($input['id'] ?? 0);
    $title = trim((string) ($input['title'] ?? ''));
    $description = trim((string) ($input['description'] ?? ''));
    $date = trim((string) ($input['event_date'] ?? '')) ?: null;
    if ($date !== null) $date = str_replace('T', ' ', $date);
    $location = trim((string) ($input['location'] ?? ''));
    $status = in_array(($input['status'] ?? ''), ['draft', 'published', 'cancelled'], true) ? $input['status'] : 'draft';
    if ($title === '' || $description === '') json_response(['error' => 'Event title and description are required.'], 422);
    $image = uploaded_image();
    if ($id) {
        $stmt = $pdo->prepare('SELECT image_path FROM events WHERE id = ?');
        $stmt->execute([$id]);
        $oldImage = $stmt->fetchColumn();
        if ($oldImage === false) json_response(['error' => 'Event not found.'], 404);
        $pdo->prepare('UPDATE events SET title=?, description=?, event_date=?, location=?, image_path=?, status=? WHERE id=?')->execute([$title, $description, $date, $location, $image ?: $oldImage, $status, $id]);
        if ($image) remove_upload($oldImage ?: null);
    } else {
        $pdo->prepare('INSERT INTO events (title, description, event_date, location, image_path, status, created_by) VALUES (?, ?, ?, ?, ?, ?, ?)')->execute([$title, $description, $date, $location, $image, $status, $actor['id']]);
        $id = (int) $pdo->lastInsertId();
    }
    audit('event.saved', 'event', $id);
    json_response(['ok' => true, 'id' => $id]);
}

if ($action === 'event-delete') {
    $id = (int) ($input['id'] ?? 0);
    $stmt = $pdo->prepare('SELECT image_path FROM events WHERE id=?');
    $stmt->execute([$id]);
    $path = $stmt->fetchColumn();
    $pdo->prepare('DELETE FROM events WHERE id=?')->execute([$id]);
    remove_upload($path ?: null);
    audit('event.deleted', 'event', $id);
    json_response(['ok' => true]);
}

if ($action === 'gallery-upload') {
    $title = trim((string) ($_POST['title'] ?? ''));
    $category = (string) ($_POST['category'] ?? 'projects');
    $alt = trim((string) ($_POST['alt_text'] ?? ''));
    if ($title === '' || !in_array($category, ['training', 'field', 'outreach', 'projects', 'events'], true)) json_response(['error' => 'Enter a title and valid gallery category.'], 422);
    $image = uploaded_image();
    if (!$image) json_response(['error' => 'Choose an image to upload.'], 422);
    $pdo->prepare('INSERT INTO gallery_images (title, category, image_path, alt_text, uploaded_by) VALUES (?, ?, ?, ?, ?)')->execute([$title, $category, $image, $alt, $actor['id']]);
    $id = (int) $pdo->lastInsertId();
    audit('gallery.uploaded', 'gallery_image', $id);
    json_response(['ok' => true, 'id' => $id], 201);
}

if ($action === 'gallery-delete') {
    $id = (int) ($input['id'] ?? 0);
    $stmt = $pdo->prepare('SELECT image_path FROM gallery_images WHERE id=?');
    $stmt->execute([$id]);
    $path = $stmt->fetchColumn();
    $pdo->prepare('DELETE FROM gallery_images WHERE id=?')->execute([$id]);
    remove_upload($path ?: null);
    audit('gallery.deleted', 'gallery_image', $id);
    json_response(['ok' => true]);
}

if ($action === 'project-save') {
    $id = (int) ($input['id'] ?? 0);
    $title = trim((string) ($input['title'] ?? ''));
    $description = trim((string) ($input['description'] ?? ''));
    $status = in_array(($input['status'] ?? ''), ['draft', 'published', 'archived'], true) ? $input['status'] : 'published';
    $order = (int) ($input['sort_order'] ?? 0);
    if ($title === '' || $description === '') json_response(['error' => 'Project title and description are required.'], 422);
    $image = uploaded_image();
    try {
        if ($id) {
            $stmt = $pdo->prepare('SELECT image_path FROM foundation_projects WHERE id=?');
            $stmt->execute([$id]);
            $old = $stmt->fetchColumn();
            if ($old === false) json_response(['error' => 'Project not found.'], 404);
            $pdo->prepare('UPDATE foundation_projects SET title=?, description=?, image_path=?, status=?, sort_order=? WHERE id=?')->execute([$title, $description, $image ?: $old, $status, $order, $id]);
            if ($image) remove_upload($old ?: null);
        } else {
            $pdo->prepare('INSERT INTO foundation_projects (title, description, image_path, status, sort_order, created_by) VALUES (?, ?, ?, ?, ?, ?)')->execute([$title, $description, $image, $status, $order, $actor['id']]);
            $id = (int) $pdo->lastInsertId();
        }
    } catch (PDOException $exception) {
        if ($exception->getCode() === '23000') json_response(['error' => 'A project with this title already exists.'], 409);
        throw $exception;
    }
    audit('project.saved', 'project', $id);
    json_response(['ok' => true, 'id' => $id]);
}

if ($action === 'project-delete') {
    $id = (int) ($input['id'] ?? 0);
    $stmt = $pdo->prepare('SELECT image_path FROM foundation_projects WHERE id=?');
    $stmt->execute([$id]);
    $path = $stmt->fetchColumn();
    $pdo->prepare('DELETE FROM foundation_projects WHERE id=?')->execute([$id]);
    remove_upload($path ?: null);
    audit('project.deleted', 'project', $id);
    json_response(['ok' => true]);
}

if ($action === 'content-save') {
    if ($actor['role'] !== 'admin') json_response(['error' => 'Administrator access is required.'], 403);
    $entries = $input['entries'] ?? [];
    if (!is_array($entries) || !$entries) json_response(['error' => 'No website copy was provided.'], 422);
    $save = $pdo->prepare('INSERT INTO site_content (content_key, content_value, updated_by) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE content_value=VALUES(content_value), updated_by=VALUES(updated_by)');
    foreach ($entries as $key => $value) {
        if (!preg_match('/^[a-z0-9._-]{1,120}$/', (string) $key) || !is_string($value) || mb_strlen($value) > 10000) json_response(['error' => 'Website text is invalid or too long.'], 422);
        $save->execute([$key, trim($value), $actor['id']]);
    }
    audit('site_content.updated', 'site_content', null, ['keys' => array_keys($entries)]);
    json_response(['ok' => true]);
}

if ($action === 'request-status') {
    $id = (int) ($input['id'] ?? 0);
    $status = (string) ($input['status'] ?? '');
    if (!in_array($status, ['submitted', 'reviewing', 'approved', 'fulfilled', 'cancelled'], true)) json_response(['error' => 'Invalid request status.'], 422);
    $pdo->beginTransaction();
    $current = $pdo->prepare('SELECT status FROM purchase_requests WHERE id=? FOR UPDATE');
    $current->execute([$id]);
    $previous = $current->fetchColumn();
    if ($previous === false) { $pdo->rollBack(); json_response(['error' => 'Request not found.'], 404); }
    if ($status === 'cancelled' && $previous !== 'cancelled') {
        $items = $pdo->prepare('SELECT product_id, quantity FROM purchase_request_items WHERE request_id=? AND product_id IS NOT NULL');
        $items->execute([$id]);
        $restore = $pdo->prepare("UPDATE products SET quantity=quantity+?, status=IF(status='out_of_stock', 'active', status) WHERE id=?");
        foreach ($items->fetchAll() as $item) $restore->execute([(int) $item['quantity'], (int) $item['product_id']]);
    }
    $pdo->prepare('UPDATE purchase_requests SET status=? WHERE id=?')->execute([$status, $id]);
    $pdo->commit();
    $owner = $pdo->prepare('SELECT customer_id FROM purchase_requests WHERE id=?');
    $owner->execute([$id]);
    $ownerId = (int) $owner->fetchColumn();
    $labels = ['submitted' => 'received', 'reviewing' => 'being reviewed', 'approved' => 'approved', 'fulfilled' => 'completed', 'cancelled' => 'cancelled'];
    if ($ownerId && $previous !== $status) notify_user($ownerId, 'order', 'Request #' . $id . ' is ' . $labels[$status], 'Open your dashboard to see the details.', '', true);
    audit('purchase_request.status_changed', 'purchase_request', $id, ['status' => $status]);
    json_response(['ok' => true]);
}

if ($action === 'user-role') {
    $id = (int) ($input['id'] ?? 0);
    $role = (string) ($input['role'] ?? '');
    if ($id === (int) $actor['id'] || !in_array($role, ['customer', 'hr', 'admin'], true)) json_response(['error' => 'Invalid user or role change.'], 422);
    $pdo->prepare('UPDATE users SET role=? WHERE id=?')->execute([$role, $id]);
    audit('user.role_changed', 'user', $id, ['role' => $role]);
    json_response(['ok' => true]);
}

if ($action === 'user-active') {
    $id = (int) ($input['id'] ?? 0);
    $active = !empty($input['is_active']) ? 1 : 0;
    if ($id === (int) $actor['id']) json_response(['error' => 'You cannot deactivate your own account.'], 422);
    $pdo->prepare('UPDATE users SET is_active=? WHERE id=?')->execute([$active, $id]);
    audit('user.active_changed', 'user', $id, ['is_active' => $active]);
    json_response(['ok' => true]);
}

if ($action === 'user-delete') {
    $id = (int) ($input['id'] ?? 0);
    if ($id === (int) $actor['id']) json_response(['error' => 'You cannot delete your own account.'], 422);
    $stmt = $pdo->prepare('SELECT first_name, last_name, email, role FROM users WHERE id=?');
    $stmt->execute([$id]);
    $target = $stmt->fetch();
    if (!$target) json_response(['error' => 'User not found.'], 404);
    if ($target['role'] === 'admin') {
        $others = $pdo->prepare("SELECT COUNT(*) FROM users WHERE role='admin' AND is_active=1 AND id<>?");
        $others->execute([$id]);
        if ((int) $others->fetchColumn() < 1) json_response(['error' => 'You cannot delete the last active administrator.'], 422);
    }
    $pdo->prepare('DELETE FROM users WHERE id=?')->execute([$id]);
    audit('user.deleted', 'user', $id, ['email' => $target['email'], 'role' => $target['role']]);
    json_response(['ok' => true]);
}

if ($action === 'reset-send-otp') {
    $id = (int) ($input['id'] ?? 0);
    $userId = (int) ($input['user_id'] ?? 0);
    if ($id) {
        $stmt = $pdo->prepare('SELECT r.id, r.user_id, r.status FROM password_reset_requests r JOIN users u ON u.id=r.user_id WHERE r.id=? AND u.is_active=1');
        $stmt->execute([$id]);
        $request = $stmt->fetch();
        if (!$request || !in_array($request['status'], ['pending_admin', 'otp_sent'], true)) json_response(['error' => 'Reset request is unavailable.'], 404);
        $userId = (int) $request['user_id'];
    } else {
        $check = $pdo->prepare('SELECT id FROM users WHERE id=? AND is_active=1');
        $check->execute([$userId]);
        if (!$check->fetchColumn()) json_response(['error' => 'The user is unavailable or deactivated.'], 404);
        $open = $pdo->prepare("SELECT id FROM password_reset_requests WHERE user_id=? AND status IN ('pending_admin', 'otp_sent') ORDER BY id DESC LIMIT 1");
        $open->execute([$userId]);
        $id = (int) $open->fetchColumn();
        if (!$id) {
            $pdo->prepare("INSERT INTO password_reset_requests (user_id, status) VALUES (?, 'pending_admin')")->execute([$userId]);
            $id = (int) $pdo->lastInsertId();
        }
    }
    $who = $pdo->prepare('SELECT first_name, last_name, email, phone FROM users WHERE id=?');
    $who->execute([$userId]);
    $target = $who->fetch();
    $otp = (string) random_int(100000, 999999);
    $pdo->prepare("UPDATE password_reset_requests SET status='otp_sent', otp_hash=?, otp_expires_at=DATE_ADD(NOW(), INTERVAL 10 MINUTE), otp_attempts=0, last_sms_at=NOW(), reviewed_by=? WHERE id=?")->execute([password_hash($otp, PASSWORD_DEFAULT), $actor['id'], $id]);
    $text = 'Your SAYI AGRO security code is ' . $otp . '. It expires in 10 minutes. Do not share it with anyone.';
    $phone = normalize_sms_phone((string) $target['phone']);
    $smsSent = $phone ? send_sms($phone, $text) : false;
    $emailSent = send_email((string) $target['email'], 'SAYI AGRO security code', $text);
    audit('password_reset.code_issued', 'password_reset_request', $id, ['sms' => $smsSent, 'email' => $emailSent]);
    $name = trim($target['first_name'] . ' ' . $target['last_name']);
    $message = 'Reset code for ' . $name . ': ' . $otp . "\n\nValid for 10 minutes.\nSMS: " . ($smsSent ? 'sent' : 'not sent') . ' | Email: ' . ($emailSent ? 'sent' : 'not sent')
        . "\n\nIf the user did not receive it, give them this code yourself after confirming who they are. They enter it on the Forgot password page under 'I already have a code'.";
    json_response(['ok' => true, 'code' => $otp, 'sms' => $smsSent, 'email' => $emailSent, 'message' => $message]);
}

if ($action === 'reset-reject') {
    $id = (int) ($input['id'] ?? 0);
    $stmt = $pdo->prepare("UPDATE password_reset_requests SET status='rejected', otp_hash=NULL, otp_expires_at=NULL, reviewed_by=? WHERE id=? AND status IN ('pending_admin', 'otp_sent')");
    $stmt->execute([$actor['id'], $id]);
    if (!$stmt->rowCount()) json_response(['error' => 'Reset request is no longer pending.'], 409);
    audit('password_reset.rejected', 'password_reset_request', $id);
    json_response(['ok' => true]);
}

json_response(['error' => 'Unknown action.'], 404);
