<?php
declare(strict_types=1);
require __DIR__ . '/common.php';

$pdo = database();
$action = $_GET['action'] ?? 'products';
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

if ($method === 'POST' && $action === 'offer') {
    $seller = require_user(['customer']);
    require_csrf();
    $name = trim((string) ($_POST['name'] ?? ''));
    $description = trim((string) ($_POST['description'] ?? ''));
    $category = trim((string) ($_POST['category'] ?? 'Other'));
    $unit = trim((string) ($_POST['unit'] ?? ''));
    $contactPhone = mb_substr(trim((string) ($_POST['contact_phone'] ?? '')), 0, 40);
    $location = mb_substr(trim((string) ($_POST['location'] ?? '')), 0, 160);
    $price = filter_var($_POST['price'] ?? null, FILTER_VALIDATE_FLOAT);
    $quantity = filter_var($_POST['quantity'] ?? null, FILTER_VALIDATE_INT);
    if ($contactPhone === '' || $location === '') json_response(['error' => 'Enter your contact phone number and your location.'], 422);
    if ($name === '' || $description === '' || $unit === '' || $price === false || $price <= 0 || $quantity === false || $quantity < 1) {
        json_response(['error' => 'Enter a name, description, price, stock quantity, and unit.'], 422);
    }
    if (empty($_FILES['image']) || $_FILES['image']['error'] !== UPLOAD_ERR_OK || $_FILES['image']['size'] > 5 * 1024 * 1024) {
        json_response(['error' => 'Choose an image up to 5 MB.'], 422);
    }
    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($_FILES['image']['tmp_name']);
    $extensions = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp', 'image/gif' => 'gif'];
    if (!isset($extensions[$mime]) || !getimagesize($_FILES['image']['tmp_name'])) json_response(['error' => 'Upload a valid JPG, PNG, WEBP, or GIF image.'], 422);
    $directory = dirname(__DIR__) . '/uploads';
    if (!is_dir($directory) && !mkdir($directory, 0755, true)) json_response(['error' => 'Upload directory is unavailable.'], 500);
    $filename = bin2hex(random_bytes(20)) . '.' . $extensions[$mime];
    if (!move_uploaded_file($_FILES['image']['tmp_name'], $directory . '/' . $filename)) json_response(['error' => 'Could not save image.'], 500);
    $stmt = $pdo->prepare("INSERT INTO products (seller_id, name, description, category, price, quantity, unit, image_path, contact_phone, location, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending')");
    $stmt->execute([$seller['id'], $name, $description, $category, $price, $quantity, $unit, 'uploads/' . $filename, $contactPhone, $location]);
    notify_user((int) $seller['id'], 'product', 'Product submitted', '"' . $name . '" is waiting for approval.', '', true);
    notify_staff('product', 'Product awaiting approval', '"' . $name . '" from ' . ($seller['name'] ?? 'a seller'), 'products', ['admin', 'hr'], (int) $seller['id']);
    json_response(['ok' => true, 'id' => (int) $pdo->lastInsertId(), 'status' => 'pending'], 201);
}

if ($method === 'GET' && $action === 'products') {
    $stmt = $pdo->query("SELECT p.id, p.name, p.description, p.category, p.price, p.quantity, p.unit, p.image_path AS image, p.status, p.location, CONCAT(u.first_name, ' ', u.last_name) AS seller FROM products p LEFT JOIN users u ON u.id=p.seller_id WHERE p.status='active' AND p.quantity > 0 ORDER BY p.created_at DESC");
    json_response(['products' => $stmt->fetchAll()]);
}

if ($method === 'GET' && $action === 'customer-dashboard') {
    $customer = require_user(['customer', 'hr', 'admin']);
    $profileStmt = $pdo->prepare('SELECT first_name, last_name, email, phone, location FROM users WHERE id=?');
    $profileStmt->execute([$customer['id']]);
    $profile = $profileStmt->fetch();
    $offersStmt = $pdo->prepare('SELECT id, name, category, price, quantity, unit, location, contact_phone, status, created_at FROM products WHERE seller_id=? ORDER BY created_at DESC');
    $offersStmt->execute([$customer['id']]);
    $requestsStmt = $pdo->prepare('SELECT id, status, total, created_at FROM purchase_requests WHERE customer_id=? ORDER BY created_at DESC');
    $requestsStmt->execute([$customer['id']]);
    $requests = $requestsStmt->fetchAll();
    $itemsStmt = $pdo->prepare('SELECT product_name, quantity, unit_price FROM purchase_request_items WHERE request_id=?');
    foreach ($requests as &$request) {
        $itemsStmt->execute([$request['id']]);
        $request['items'] = $itemsStmt->fetchAll();
    }
    unset($request);
    $cartProducts = $pdo->query("SELECT id, name, price, quantity, unit, image_path AS image FROM products WHERE status='active' AND quantity > 0 ORDER BY name")->fetchAll();
    json_response(['profile' => $profile, 'offers' => $offersStmt->fetchAll(), 'requests' => $requests, 'products' => $cartProducts, 'csrf' => csrf_token()]);
}

if ($method === 'POST' && $action === 'order') {
    $customer = require_user(['customer', 'hr', 'admin']);
    require_csrf();
    $input = request_json();
    $items = $input['items'] ?? [];
    if (!is_array($items) || !$items) json_response(['error' => 'Your cart is empty.'], 422);

    $quantities = [];
    foreach ($items as $item) {
        $id = filter_var($item['id'] ?? null, FILTER_VALIDATE_INT);
        $quantity = filter_var($item['quantity'] ?? null, FILTER_VALIDATE_INT);
        if (!$id || !$quantity || $quantity < 1 || $quantity > 100) json_response(['error' => 'Cart contains an invalid item or quantity.'], 422);
        $quantities[$id] = ($quantities[$id] ?? 0) + $quantity;
    }

    try {
        $pdo->beginTransaction();
        $lockedProducts = [];
        $find = $pdo->prepare("SELECT id, name, price, quantity, unit FROM products WHERE id=? AND status='active' FOR UPDATE");
        foreach ($quantities as $id => $quantity) {
            $find->execute([$id]);
            $product = $find->fetch();
            if (!$product || (int) $product['quantity'] < $quantity) {
                $pdo->rollBack();
                json_response(['error' => 'One or more products are no longer available in the requested quantity.'], 409);
            }
            $lockedProducts[$id] = $product;
        }

        $total = 0.0;
        foreach ($lockedProducts as $id => $product) $total += (float) $product['price'] * $quantities[$id];
        $insert = $pdo->prepare("INSERT INTO purchase_requests (customer_id, total, status) VALUES (?, ?, 'submitted')");
        $insert->execute([$customer['id'], $total]);
        $requestId = (int) $pdo->lastInsertId();
        $insertItem = $pdo->prepare('INSERT INTO purchase_request_items (request_id, product_id, product_name, quantity, unit_price) VALUES (?, ?, ?, ?, ?)');
        $decrement = $pdo->prepare("UPDATE products SET status=IF(quantity <= ?, 'out_of_stock', 'active'), quantity=quantity-? WHERE id=?");
        foreach ($lockedProducts as $id => $product) {
            $quantity = $quantities[$id];
            $insertItem->execute([$requestId, $id, $product['name'], $quantity, $product['price']]);
            $decrement->execute([$quantity, $quantity, $id]);
        }
        $pdo->commit();
        notify_user((int) $customer['id'], 'order', 'Request #' . $requestId . ' received', 'Total TZS ' . number_format($total) . '. Continue the conversation on WhatsApp to finish your order.', '', true);
        notify_staff('order', 'New purchase request #' . $requestId, $customer['name'] . ' - TZS ' . number_format($total), 'requests', ['admin', 'hr'], (int) $customer['id']);
        global $config;
        $phoneStmt = $pdo->prepare('SELECT phone, location FROM users WHERE id=?');
        $phoneStmt->execute([$customer['id']]);
        $buyer = $phoneStmt->fetch() ?: [];
        $lines = ['Habari SAYI AGRO, ningependa kununua bidhaa zifuatazo (Ombi #' . $requestId . '):'];
        foreach ($lockedProducts as $id => $product) {
            $lines[] = '- ' . $product['name'] . ' x ' . $quantities[$id] . ' ' . $product['unit'] . ' = TZS ' . number_format((float) $product['price'] * $quantities[$id]);
        }
        $lines[] = 'Jumla: TZS ' . number_format($total);
        $lines[] = 'Jina: ' . $customer['name'];
        if (!empty($buyer['phone'])) $lines[] = 'Simu: ' . $buyer['phone'];
        if (!empty($buyer['location'])) $lines[] = 'Eneo: ' . $buyer['location'];
        $whatsappUrl = 'https://wa.me/' . $config['whatsapp_number'] . '?text=' . rawurlencode(implode("\n", $lines));
        json_response(['ok' => true, 'request_id' => $requestId, 'total' => $total, 'whatsapp_url' => $whatsappUrl], 201);
    } catch (Throwable $exception) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        throw $exception;
    }
}

if ($method === 'GET' && $action === 'projects') {
    json_response(['projects' => $pdo->query("SELECT id, title, description, image_path AS image FROM foundation_projects WHERE status='published' ORDER BY sort_order, id")->fetchAll()]);
}

if ($method === 'GET' && $action === 'events') {
    json_response(['events' => $pdo->query("SELECT id, title, description, event_date, location, image_path FROM events WHERE status='published' ORDER BY event_date DESC")->fetchAll()]);
}

if ($method === 'GET' && $action === 'gallery') {
    json_response(['images' => $pdo->query('SELECT id, title, category, image_path, alt_text FROM gallery_images ORDER BY created_at DESC')->fetchAll()]);
}

json_response(['error' => 'Unknown action.'], 404);
