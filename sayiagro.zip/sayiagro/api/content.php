<?php
declare(strict_types=1);
require __DIR__ . '/common.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    json_response(['error' => 'Method not allowed.'], 405);
}
$rows = database()->query('SELECT content_key, content_value FROM site_content')->fetchAll();
$content = [];
foreach ($rows as $row) $content[$row['content_key']] = $row['content_value'];
json_response(['content' => $content]);
