<?php
declare(strict_types=1);
require __DIR__ . '/common.php';

$user = require_user();
$pdo = database();
$action = $_GET['action'] ?? '';
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

function conversation_for_user(PDO $pdo, int $conversationId, array $user, bool $lock = false): ?array
{
    $sql = 'SELECT * FROM conversations WHERE id = ?' . ($lock ? ' FOR UPDATE' : '');
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$conversationId]);
    $conversation = $stmt->fetch();
    if (!$conversation) return null;
    if ($user['role'] === 'admin') return $conversation;
    if ($conversation['kind'] === 'customer_hr' && $user['role'] === 'customer' && (int) $conversation['customer_id'] === (int) $user['id']) return $conversation;
    if ($conversation['kind'] === 'hr_admin' && $user['role'] === 'hr' && (int) $conversation['hr_id'] === (int) $user['id']) return $conversation;
    if ($conversation['kind'] === 'customer_hr' && $user['role'] === 'hr' && ($conversation['hr_id'] === null || (int) $conversation['hr_id'] === (int) $user['id'])) return $conversation;
    return null;
}

if ($method === 'GET' && $action === 'conversations') {
    if ($user['role'] === 'admin') {
        $rows = $pdo->query('SELECT c.*, cu.email AS customer_email, CONCAT(cu.first_name, \' \', cu.last_name) AS customer_name, hu.email AS hr_email, au.email AS admin_email FROM conversations c LEFT JOIN users cu ON cu.id=c.customer_id LEFT JOIN users hu ON hu.id=c.hr_id LEFT JOIN users au ON au.id=c.admin_id ORDER BY c.updated_at DESC')->fetchAll();
    } elseif ($user['role'] === 'hr') {
        $stmt = $pdo->prepare("SELECT c.*, cu.email AS customer_email, CONCAT(cu.first_name, ' ', cu.last_name) AS customer_name FROM conversations c LEFT JOIN users cu ON cu.id=c.customer_id WHERE (c.kind='customer_hr' AND (c.hr_id=? OR c.hr_id IS NULL)) OR (c.kind='hr_admin' AND c.hr_id=?) ORDER BY c.updated_at DESC");
        $stmt->execute([$user['id'], $user['id']]);
        $rows = $stmt->fetchAll();
    } else {
        $stmt = $pdo->prepare("SELECT c.*, hu.email AS hr_email FROM conversations c LEFT JOIN users hu ON hu.id=c.hr_id WHERE c.kind='customer_hr' AND c.customer_id=? ORDER BY c.updated_at DESC");
        $stmt->execute([$user['id']]);
        $rows = $stmt->fetchAll();
    }
    json_response(['conversations' => $rows]);
}

if ($method === 'GET' && $action === 'messages') {
    $id = (int) ($_GET['conversation_id'] ?? 0);
    if (!conversation_for_user($pdo, $id, $user)) json_response(['error' => 'Conversation not found.'], 404);
    $stmt = $pdo->prepare('SELECT m.id, m.body, m.created_at, m.sender_id, u.email AS sender_email, CONCAT(u.first_name, \' \', u.last_name) AS sender_name, u.role AS sender_role FROM messages m JOIN users u ON u.id=m.sender_id WHERE m.conversation_id=? ORDER BY m.created_at ASC');
    $stmt->execute([$id]);
    json_response(['messages' => $stmt->fetchAll()]);
}

if ($method === 'POST') {
    require_csrf();
    $input = request_json();
    if ($action === 'conversation-create') {
        if ($user['role'] === 'customer') {
            $subject = trim((string) ($input['subject'] ?? 'Customer support'));
            $pdo->prepare("INSERT INTO conversations (subject, kind, customer_id) VALUES (?, 'customer_hr', ?)")->execute([$subject, $user['id']]);
        } elseif ($user['role'] === 'hr') {
            if (($input['target_type'] ?? '') === 'customer') {
                $targetId = (int) ($input['target_id'] ?? 0);
                $check = $pdo->prepare("SELECT id FROM users WHERE id=? AND role='customer' AND is_active=1");
                $check->execute([$targetId]);
                if (!$check->fetchColumn()) json_response(['error' => 'The selected customer is unavailable.'], 422);
                $subject = trim((string) ($input['subject'] ?? 'Customer support'));
                $pdo->prepare("INSERT INTO conversations (subject, kind, customer_id, hr_id) VALUES (?, 'customer_hr', ?, ?)")->execute([$subject, $targetId, $user['id']]);
            } else {
                $subject = trim((string) ($input['subject'] ?? 'HR and admin'));
            $pdo->prepare("INSERT INTO conversations (subject, kind, hr_id, admin_id) VALUES (?, 'hr_admin', ?, (SELECT id FROM users WHERE role='admin' AND is_active=1 ORDER BY id LIMIT 1))")->execute([$subject, $user['id']]);
            }
        } else {
            $targetType = (string) ($input['target_type'] ?? '');
            $targetId = (int) ($input['target_id'] ?? 0);
            $role = $targetType === 'customer' ? 'customer' : ($targetType === 'hr' ? 'hr' : '');
            if ($role === '') json_response(['error' => 'Choose a customer or HR recipient.'], 422);
            $check = $pdo->prepare('SELECT id FROM users WHERE id=? AND role=? AND is_active=1');
            $check->execute([$targetId, $role]);
            if (!$check->fetchColumn()) json_response(['error' => 'The selected recipient is unavailable.'], 422);
            $subject = trim((string) ($input['subject'] ?? ($role === 'customer' ? 'Customer support' : 'Admin and HR')));
            if ($role === 'customer') {
                $pdo->prepare("INSERT INTO conversations (subject, kind, customer_id, admin_id) VALUES (?, 'customer_hr', ?, ?)")->execute([$subject, $targetId, $user['id']]);
            } else {
                $pdo->prepare("INSERT INTO conversations (subject, kind, hr_id, admin_id) VALUES (?, 'hr_admin', ?, ?)")->execute([$subject, $targetId, $user['id']]);
            }
        }
        $id = (int) $pdo->lastInsertId();
        json_response(['ok' => true, 'conversation_id' => $id], 201);
    }

    if ($action === 'assign') {
        if ($user['role'] !== 'admin') json_response(['error' => 'Administrator access is required.'], 403);
        $conversationId = (int) ($input['conversation_id'] ?? 0);
        $hrId = (int) ($input['hr_id'] ?? 0);
        $check = $pdo->prepare("SELECT id FROM users WHERE id=? AND role='hr' AND is_active=1");
        $check->execute([$hrId]);
        if (!$check->fetchColumn()) json_response(['error' => 'Choose an active HR user.'], 422);
        $stmt = $pdo->prepare("UPDATE conversations SET hr_id=? WHERE id=? AND kind='customer_hr'");
        $stmt->execute([$hrId, $conversationId]);
        json_response(['ok' => true]);
    }

    if ($action === 'send') {
        $conversationId = (int) ($input['conversation_id'] ?? 0);
        $body = trim((string) ($input['body'] ?? ''));
        if (mb_strlen($body) < 1 || mb_strlen($body) > 5000) json_response(['error' => 'Message must be between 1 and 5000 characters.'], 422);
        $conv = conversation_for_user($pdo, $conversationId, $user);
        if (!$conv) json_response(['error' => 'Conversation not found.'], 404);
        if ($user['role'] === 'hr') $pdo->prepare("UPDATE conversations SET hr_id=? WHERE id=? AND kind='customer_hr' AND hr_id IS NULL")->execute([$user['id'], $conversationId]);
        $pdo->beginTransaction();
        $pdo->prepare('INSERT INTO messages (conversation_id, sender_id, body) VALUES (?, ?, ?)')->execute([$conversationId, $user['id'], $body]);
        $pdo->prepare('UPDATE conversations SET updated_at=NOW() WHERE id=?')->execute([$conversationId]);
        $pdo->commit();
        $conv = conversation_for_user($pdo, $conversationId, $user) ?: $conv;
        $preview = mb_substr($body, 0, 120);
        $senderName = (string) ($user['name'] ?? 'Someone');
        if ($conv['kind'] === 'customer_hr') {
            if ($user['role'] === 'customer') {
                if (!empty($conv['hr_id'])) notify_user((int) $conv['hr_id'], 'chat', 'New message from ' . $senderName, $preview, 'chat');
                else notify_staff('chat', 'New customer message from ' . $senderName, $preview, 'chat', ['hr', 'admin']);
            } else {
                $recent = $pdo->prepare("SELECT COUNT(*) FROM notifications WHERE user_id=? AND type='chat' AND created_at > DATE_SUB(NOW(), INTERVAL 10 MINUTE)");
                $recent->execute([(int) $conv['customer_id']]);
                notify_user((int) $conv['customer_id'], 'chat', 'New message from SAYI AGRO support', $preview, '', (int) $recent->fetchColumn() === 0);
            }
        } else {
            $other = (int) $user['id'] === (int) $conv['hr_id'] ? (int) $conv['admin_id'] : (int) $conv['hr_id'];
            if ($other) notify_user($other, 'chat', 'New message from ' . $senderName, $preview, 'chat');
        }
        json_response(['ok' => true]);
    }
}

json_response(['error' => 'Unknown action.'], 404);
