<?php
declare(strict_types=1);
require __DIR__ . '/common.php';

$user = require_user();
$pdo = database();
$action = $_GET['action'] ?? 'list';
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

if ($method === 'GET') {
    $stmt = $pdo->prepare('SELECT id, type, title, body, link, is_read, created_at FROM notifications WHERE user_id = ? ORDER BY id DESC LIMIT 50');
    $stmt->execute([$user['id']]);
    $count = $pdo->prepare('SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0');
    $count->execute([$user['id']]);
    json_response(['notifications' => $stmt->fetchAll(), 'unread' => (int) $count->fetchColumn()]);
}

if ($method === 'POST') {
    require_csrf();
    $input = request_json();
    if ($action === 'read') {
        $pdo->prepare('UPDATE notifications SET is_read = 1 WHERE id = ? AND user_id = ?')->execute([(int) ($input['id'] ?? 0), $user['id']]);
        json_response(['ok' => true]);
    }
    if ($action === 'read-all') {
        $pdo->prepare('UPDATE notifications SET is_read = 1 WHERE user_id = ? AND is_read = 0')->execute([$user['id']]);
        json_response(['ok' => true]);
    }
}

json_response(['error' => 'Unknown action.'], 404);
