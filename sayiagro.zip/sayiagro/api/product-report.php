<?php
declare(strict_types=1);
require __DIR__ . '/common.php';
require_user(['admin', 'hr']);

if (($_GET['format'] ?? '') === 'print') {
    $rows = database()->query("SELECT p.id, p.name, p.category, u.email AS seller, p.price, p.quantity, p.unit, p.status, p.created_at FROM products p LEFT JOIN users u ON u.id=p.seller_id ORDER BY p.created_at DESC")->fetchAll();
    $h = static fn($v) => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
    $visible = 0; $hidden = 0; $units = 0; $value = 0.0; $by = [];
    foreach ($rows as $r) {
        $by[$r['status']] = ($by[$r['status']] ?? 0) + 1;
        if ($r['status'] === 'active' && (int) $r['quantity'] > 0) { $visible++; $value += (float) $r['price'] * (int) $r['quantity']; } else { $hidden++; }
        $units += (int) $r['quantity'];
    }
    header('Content-Type: text/html; charset=utf-8');
    header('Cache-Control: no-store');
    echo '<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><title>Product report | SAYI AGRO FOUNDATION</title><style>body{font-family:Segoe UI,Arial,sans-serif;margin:32px;color:#26352d}header{display:flex;align-items:center;gap:14px;border-bottom:3px solid #28724f;padding-bottom:12px}header img{height:56px}h1{margin:0;font-size:22px;color:#163f35}p{margin:2px 0;color:#68776e}.sum{display:flex;flex-wrap:wrap;gap:10px;margin:18px 0}.sum div{border:1px solid #d7e0d5;border-radius:8px;padding:10px 14px;min-width:140px}.sum strong{display:block;font-size:20px}table{width:100%;border-collapse:collapse;font-size:13px}th,td{border:1px solid #d7e0d5;padding:7px 8px;text-align:left}th{background:#eef4e8}.r{text-align:right}button{margin:14px 0;padding:9px 16px;border:0;border-radius:6px;background:#28724f;color:#fff;font-weight:700;cursor:pointer}@media print{button{display:none}body{margin:12px}}</style></head><body>';
    echo '<header><img src="../logo.png" alt="SAYI AGRO logo"><div><h1>SAYI AGRO FOUNDATION - Product report</h1><p>Generated ' . $h(date('Y-m-d H:i')) . '</p></div></header>';
    echo '<button onclick="window.print()">Print / Save as PDF</button><div class="sum">';
    echo '<div><span>All products</span><strong>' . count($rows) . '</strong></div><div><span>Visible to customers</span><strong>' . $visible . '</strong></div><div><span>Hidden / unavailable</span><strong>' . $hidden . '</strong></div><div><span>Total units in stock</span><strong>' . $units . '</strong></div><div><span>Stock value (visible)</span><strong>TZS ' . number_format($value) . '</strong></div>';
    foreach ($by as $status => $count) echo '<div><span>' . $h(str_replace('_', ' ', $status)) . '</span><strong>' . $count . '</strong></div>';
    echo '</div><table><thead><tr><th>#</th><th>Product</th><th>Category</th><th>Seller</th><th class="r">Price (TZS)</th><th class="r">Stock</th><th>Status</th><th>Created</th></tr></thead><tbody>';
    foreach ($rows as $r) echo '<tr><td>' . (int) $r['id'] . '</td><td>' . $h($r['name']) . '</td><td>' . $h($r['category']) . '</td><td>' . $h($r['seller'] ?: 'Foundation') . '</td><td class="r">' . number_format((float) $r['price']) . '</td><td class="r">' . (int) $r['quantity'] . ' ' . $h($r['unit']) . '</td><td>' . $h(str_replace('_', ' ', $r['status'])) . '</td><td>' . $h($r['created_at']) . '</td></tr>';
    echo '</tbody></table></body></html>';
    exit;
}

header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="sayiagro-products-' . date('Y-m-d') . '.csv"');
header('Cache-Control: no-store');
$output = fopen('php://output', 'wb');
fwrite($output, "\xEF\xBB\xBF");
fputcsv($output, ['ID', 'Product', 'Category', 'Seller email', 'Seller phone', 'Location', 'Price TZS', 'Quantity', 'Unit', 'Status', 'Created']);
$stmt = database()->query('SELECT p.id, p.name, p.category, u.email, p.contact_phone, p.location, p.price, p.quantity, p.unit, p.status, p.created_at FROM products p LEFT JOIN users u ON u.id=p.seller_id ORDER BY p.created_at DESC');
while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
    foreach ($row as &$value) {
        $value = (string) ($value ?? '');
        if ($value !== '' && in_array($value[0], ['=', '+', '-', '@', "\t", "\r"], true)) $value = "'" . $value;
    }
    unset($value);
    fputcsv($output, $row);
}
fclose($output);
