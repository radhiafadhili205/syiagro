-- SAYI AGRO: akaunti za Admin na HR
USE sayiagro;
INSERT INTO users (first_name, last_name, email, password_hash, role, is_active) VALUES
('Admin','SAYI','admin@sayiagro.org','$2y$10$E.DxzOOPK7tL5eLmLkL.Ye7HsM3rzGYaVTszzo9AAoq5hT1/VKHDi','admin',1),
('HR','SAYI','hr@sayiagro.org','$2y$10$3znw0jcPT1UUtw9i1rodu.Pn39jmt97Sk/RhJt2Dthc2d/dJ6P9Ba','hr',1)
ON DUPLICATE KEY UPDATE password_hash=VALUES(password_hash), role=VALUES(role), is_active=1;
