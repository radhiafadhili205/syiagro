-- Kwa database iliyokwisha ingizwa (XAMPP/MariaDB). Ingiza mara moja kupitia phpMyAdmin.
USE sayiagro;
ALTER TABLE users ADD COLUMN IF NOT EXISTS location VARCHAR(160) NOT NULL DEFAULT '' AFTER phone;
ALTER TABLE products ADD COLUMN IF NOT EXISTS contact_phone VARCHAR(40) NOT NULL DEFAULT '' AFTER image_path;
ALTER TABLE products ADD COLUMN IF NOT EXISTS location VARCHAR(160) NOT NULL DEFAULT '' AFTER contact_phone;
