<?php
declare(strict_types=1);
require __DIR__ . '/api/common.php';

$message = '';
$error = '';
$isLocalSetup = in_array($_SERVER['REMOTE_ADDR'] ?? '', ['127.0.0.1', '::1'], true);
$hasAdmin = (int) database()->query("SELECT COUNT(*) FROM users WHERE role='admin'")->fetchColumn() > 0;
if (empty($_SESSION['setup_csrf'])) $_SESSION['setup_csrf'] = bin2hex(random_bytes(32));

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if (!$isLocalSetup) {
    $error = 'Initial admin setup is only allowed from this computer.';
  } elseif (!hash_equals($_SESSION['setup_csrf'], (string) ($_POST['_csrf'] ?? ''))) {
        $error = 'Security token expired. Reload and try again.';
    } elseif ($hasAdmin) {
        $error = 'An administrator account already exists. This setup page is locked.';
    } else {
        $first = trim((string) ($_POST['first_name'] ?? ''));
        $last = trim((string) ($_POST['last_name'] ?? ''));
        $email = strtolower(trim((string) ($_POST['email'] ?? '')));
        $password = (string) ($_POST['password'] ?? '');
        if (mb_strlen($first) < 2 || mb_strlen($last) < 2 || !filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($password) < 12) {
            $error = 'Enter valid names/email and a password of at least 12 characters.';
        } elseif (!database()->query("SELECT GET_LOCK('sayiagro_admin_setup', 5)")->fetchColumn()) {
            $error = 'Setup is busy. Try again.';
        } else {
            try {
                $hasAdmin = (int) database()->query("SELECT COUNT(*) FROM users WHERE role='admin'")->fetchColumn() > 0;
                if ($hasAdmin) {
                    $error = 'An administrator account already exists.';
                } else {
                    $stmt = database()->prepare("INSERT INTO users (first_name, last_name, email, password_hash, role) VALUES (?, ?, ?, ?, 'admin')");
                    $stmt->execute([$first, $last, $email, password_hash($password, PASSWORD_DEFAULT)]);
                    $message = 'Administrator created. Sign in, then remove or restrict setup_admin.php.';
                    $hasAdmin = true;
                }
            } catch (PDOException $exception) {
                $error = $exception->getCode() === '23000' ? 'That email is already registered.' : 'Could not create administrator.';
            } finally {
                database()->query("SELECT RELEASE_LOCK('sayiagro_admin_setup')");
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Initial Admin Setup | SAYI AGRO FOUNDATION</title>
  <link rel="stylesheet" href="site-footer.css" />
  <style>
    body { margin: 0; background: #f4f7f1; color: #26352d; font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif; }
    main { width: min(520px, calc(100% - 32px)); margin: 8vh auto; padding: 28px; border: 1px solid #e2e8de; border-radius: 10px; background: #fff; }
    h1 { margin: 0 0 8px; color: #163f35; }
    p { color: #68776e; }
    label { display: grid; gap: 6px; margin: 14px 0; color: #43564b; font-weight: 700; }
    input { padding: 11px; border: 1px solid #d7e0d5; border-radius: 6px; font: inherit; }
    button, .login { display: inline-block; padding: 11px 16px; border: 0; border-radius: 6px; background: #28724f; color: #fff; font: inherit; font-weight: 700; text-decoration: none; cursor: pointer; }
    .notice { padding: 12px; border-radius: 6px; background: #eef4e8; color: #385532; }
    .error { background: #faece9; color: #963d31; }
  </style>
</head>
<body>
  <main>
    <span>FIRST-RUN SECURITY</span>
    <h1>Set up the first admin</h1>
    <p>This one-time form is available only while the database has no administrator account.</p>
    <?php if (!$isLocalSetup): ?><p class="notice error">Initial admin setup is only available on the local XAMPP computer.</p><?php endif; ?>
    <?php if ($error !== ''): ?><p class="notice error"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></p><?php endif; ?>
    <?php if ($message !== ''): ?><p class="notice"><?= htmlspecialchars($message, ENT_QUOTES, 'UTF-8') ?></p><a class="login" href="login.html">Go to login</a>
    <?php elseif (!$isLocalSetup): ?>
    <?php elseif ($hasAdmin): ?><p class="notice">An administrator already exists. This setup form is disabled.</p>
    <?php else: ?>
      <form method="post" autocomplete="off">
        <input type="hidden" name="_csrf" value="<?= htmlspecialchars($_SESSION['setup_csrf'], ENT_QUOTES, 'UTF-8') ?>" />
        <label>First name<input name="first_name" required minlength="2" maxlength="80" /></label>
        <label>Last name<input name="last_name" required minlength="2" maxlength="80" /></label>
        <label>Email<input name="email" type="email" required maxlength="190" /></label>
        <label>Password (minimum 12 characters)<input name="password" type="password" required minlength="12" autocomplete="new-password" /></label>
        <button type="submit">Create administrator</button>
      </form>
    <?php endif; ?>
  </main>
</body>
</html>
