# SAYI AGRO PHP/MySQL setup (XAMPP)

## 1. Put the site under Apache

Copy the complete `SAYIAGRO` folder into `C:\xampp\htdocs\SAYIAGRO`. Do not open the HTML/PHP files with `file://`; PHP APIs and sessions only work through Apache.

Start **Apache** and **MySQL** in the XAMPP Control Panel.

## 2. Create the database

1. Open `http://localhost/phpmyadmin`.
2. Import `database.sql` from this project folder. The script uses `CREATE TABLE IF NOT EXISTS` and organization contact settings only (no sample content), so it can be imported again to add newly added tables without dropping existing rows.
3. Confirm the `sayiagro` database and its tables were created.

The default local XAMPP MySQL user in `config.php` is `root` with an empty password. Set `SAYIAGRO_DB_USER` and `SAYIAGRO_DB_PASSWORD` in the PHP/Apache environment, or change the local-only config values, if your MySQL root account has a password. Set `SAYIAGRO_APP_URL` to `http://localhost/SAYIAGRO` if you use a different folder name.

Enable/check these PHP extensions in `C:\xampp\php\php.ini`: `pdo_mysql`, `fileinfo`, and `mbstring`. For image uploads, allow a request larger than 5 MB using `upload_max_filesize` and `post_max_size`; restart Apache after changes.

## 3. Create the first administrator

**Akaunti za Admin na HR:** badala ya `setup_admin.php`, unaweza kuingiza `create_admin_hr.sql` kupitia phpMyAdmin (database `sayiagro`). Taarifa za kuingia ziko kwenye `credentials.txt` - badilisha password baada ya kuingia, kisha ufute `credentials.txt`.

Open `http://localhost/SAYIAGRO/setup_admin.php` and create the initial admin using a strong password of at least 12 characters. Once created, the setup page locks itself. Remove `setup_admin.php` from the deployed site after setup.

Sign in at `http://localhost/SAYIAGRO/login.html`. Admin accounts open `admindashboard.html`; HR accounts open the separate `hrportal.html` for assigned customer chats and admin coordination. Customers remain in the marketplace. Customer self-registration remains customer-only. An administrator can promote an existing customer to HR from Users.

## 4. Configure SMS and password-reset email

Password recovery works in this order: the customer requests recovery with their email; the admin reviews the request and sends a six-digit OTP to the phone saved on that account; after OTP verification, the customer receives a one-time reset link at their account email. The OTP expires after 10 minutes, allows at most five guesses, and admins must wait one minute before resending. The email link expires after 60 minutes. The customer chooses a new password on that link. No shared default password such as `123456` is created or emailed.

SMS uses Africa's Talking. Configure these values in the Apache/PHP environment; do not put API keys in public files:

- `SAYIAGRO_SMS_USERNAME` (use `sandbox` while testing)
- `SAYIAGRO_SMS_API_KEY`
- `SAYIAGRO_SMS_API_URL` (`https://api.sandbox.africastalking.com/version1/messaging` for sandbox, or the live endpoint after enabling the account)
- `SAYIAGRO_SMS_SENDER` (optional; use a sender ID approved by the provider)

Enable PHP cURL and test delivery with a phone number you control. Sandbox messages may not arrive as ordinary live SMS; follow Africa's Talking sandbox recipient setup.

Email delivery uses PHP `mail()`. Configure XAMPP `sendmail.ini` with your SMTP host, port, username, and app password, set `sendmail_path` in `php.ini` to XAMPP's `sendmail.exe`, and restart Apache. Set `SAYIAGRO_MAIL_FROM` to an address accepted by the SMTP provider. Test with a mailbox you control. The recovery response does not disclose whether an email account exists.

## Features

- Admin: product CRUD, clone, pending-offer approval, stock status, events, gallery uploads, purchase request status, customer/HR roles, profile, CSV product report, and chat.
- HR: dashboard overview, assigned/unassigned customer support conversations, HR/admin conversations, and profile.
- Customer: account registration/login, product browsing, cart, stock-checked purchase requests, product offers pending approval, and HR support chat.
- Database coverage: users/roles, products and stock, programs, projects, events, gallery, homepage slides, editable public copy and organization settings, contact messages, purchase requests/items, HR conversations/messages, password reset requests/tokens, and audit history.
- Uploaded images are limited to JPG, PNG, WEBP, or GIF, up to 5 MB.

## Important deployment notes

- This version uses MySQL and PHP sessions, so accounts, products, events, gallery uploads, orders, and messages are shared across browsers on the same server.
- Orders are purchase requests only; online payment processing is not configured.
- Use HTTPS in production. Set a database password, configure SMTP, back up the database and `uploads/`, and remove `setup_admin.php` after initial setup.

## Roles and permissions

- **Admin** (`admindashboard.html`): everything - products, requests, events, gallery, projects, site text, password resets, users/roles, messages, product reports.
- **HR** (same dashboard after login, restricted): products (add, clone, hide when out of stock, delete), purchase requests, events, gallery, projects, product reports, and chat with customers/admin. HR cannot open Site text, Password resets or Users (the server enforces this in `api/admin.php`).
- **Customer** (`customerdashboard.html`): cart, purchase requests, offers, profile and chat with HR.

## WhatsApp checkout, sellers and buyers

- **Database iliyokwisha ingizwa:** ingiza `migration_v2.sql` mara moja kupitia phpMyAdmin (inaongeza `location` na `contact_phone`). Database mpya inatosha kuingiza `database.sql`.
- **Namba ya WhatsApp ya biashara:** iko kwenye `config.php` (`whatsapp_number`, chaguo-msingi 255785125046). Badilisha hapo au weka `SAYIAGRO_WHATSAPP` (code ya nchi, bila +).
- **Cart:** mteja anaongeza/anaondoa bidhaa kwenye cart; akibonyeza *Order via WhatsApp* ombi linahifadhiwa (stock inahifadhiwa) kisha anapelekwa WhatsApp na orodha ya bidhaa, jumla, jina, simu na eneo. Admin akifuta/kughairi ombi, stock inarudishwa.
- **Wauzaji:** wanajisajili (`joinUS.html`) na simu na eneo, kisha wanapakia bidhaa na picha kwenye Marketplace (simu na eneo vinahitajika). Admin/HR wanaidhinisha. Eneo linaonekana kwa wateja; simu ya muuzaji inaonekana kwa admin/HR tu.
- **HR na admin** wanaweza kununua kupitia Marketplace kwa cart hiyo hiyo.
