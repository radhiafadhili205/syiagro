async function applySiteContent() {
  try {
    const response = await fetch('api/content.php', { headers: { Accept: 'application/json' } });
    if (!response.ok) return;
    const result = await response.json();
    const contentElements = document.querySelectorAll('[data-site-copy]');
    Object.entries(result.content || {}).forEach(([key, value]) => {
      contentElements.forEach((element) => {
        if (element.dataset.siteCopy === key) element.textContent = value;
      });
    });
  } catch (error) {
    console.error('Could not load managed site copy.', error);
  }
}

applySiteContent();
